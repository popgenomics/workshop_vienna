echo "dataset,option" > prov1
echo "nb_gene,ntopo0,ntopo1,ntopo2,ntopo3,mean_lg,tau1,tau1_l,tau1_h,tau2,tau2_l,tau2_h,theta,theta_l,theta_h,pab,pab_l,pab_h,pac,pac_l,pac_h,pbc,pbc_l,pbc_h,pa,pa_l,pa_h,noevent,noconflict_ILS,noconflict_GF,conflict_ILS,conflict_ILS_l,conflict_ILS_h,conflict_GF,conflict_GF_l,conflict_GF_h,imbalance_ILS,dominant_ILS,imbalance_GF,dominant_GF,lnL" > prov2

for f in homininae macaca papionini
do
  echo "dataset,option" > prov1
  echo "nb_gene,ntopo0,ntopo1,ntopo2,ntopo3,mean_lg,tau1,tau1_l,tau1_h,tau2,tau2_l,tau2_h,theta,theta_l,theta_h,pab,pab_l,pab_h,pac,pac_l,pac_h,pbc,pbc_l,pbc_h,pa,pa_l,pa_h,noevent,noconflict_ILS,noconflict_GF,conflict_ILS,conflict_ILS_l,conflict_ILS_h,conflict_GF,conflict_GF_l,conflict_GF_h,imbalance_ILS,dominant_ILS,imbalance_GF,dominant_GF,lnL" > prov2
  echo ./tax_files/$f.tax,basic.opt >> prov1
  ../aphid/aphid0.11 in_files/$f.in tax_files/$f.tax opt_files/basic.opt ./outputs/$f.csv >> prov2
  paste -d"," prov1 prov2 > ./$f.csv
done

#paste -d"," prov1 prov2 > primates.csv

#Rscript primates.R > prov4

rm prov1
rm prov2
#rm prov3
#rm prov4




