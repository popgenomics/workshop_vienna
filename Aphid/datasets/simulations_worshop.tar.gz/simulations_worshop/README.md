These datasets can be used to test **Aphid** on simulated phylogenomic data across varying proportions of genes affected by gene flow (GF).

# Data

The expected species tree topology is:

```text
          /- 5
       /-|
    /-|   \- 4
    | |
    |  \- 6
  /-|
  | |      /- 1
  | |   /-|
  |  \-|   \- 2
  |     \- 3
--|  
  |   
  |      /- 7
  |   /-|
   \-|   \- 8
     |   
      \- 9
```

- **Focal species:** 1, 2, and 3
- **Outgroup species:** 7, 8, and 9
- **Other related taxa:** 4, 5, and 6

Two simulation conditions are provided:
- **Low ILS:** 2% incomplete lineage sorting between focal species.
- **High ILS:** 33% incomplete lineage sorting between focal species.

---

# Create a Custom Dataset

The script `scripts/personal_dataset.py` generates datasets based on user-defined proportions of genes affected by multiple gene flow events between focal species. 

Running the script produces two datasets matching your specifications: one under 2% ILS and one under 33% ILS.

Run the script and follow the interactive prompts:

```bash
python scripts/personal_dataset.py
```

# Run Aphid Analysis

Input files are stored in the `aphid_input/` directory.

To run Aphid in non-verbose mode, execute:

```bash
bash scripts/run_aphid.sh
```