echo "dataset,option" > prov1
echo "nb_gene,ntopo0,ntopo1,ntopo2,ntopo3,mean_lg,tau1,tau1_l,tau1_h,tau2,tau2_l,tau2_h,theta,theta_l,theta_h,pab,pab_l,pab_h,pac,pac_l,pac_h,pbc,pbc_l,pbc_h,pa,pa_l,pa_h,noevent,noconflict_ILS,noconflict_GF,conflict_ILS,conflict_ILS_l,conflict_ILS_h,conflict_GF,conflict_GF_l,conflict_GF_h,imbalance_ILS,dominant_ILS,imbalance_GF,dominant_GF,lnL" > prov2

echo ./aphid_input/simulations.tax,basic.opt >> prov1
../../software/aphid/aphid aphid_input/simulations_ils_2.in aphid_input/simulations.tax aphid_input/config.opt outputs/simulations_ils_2.csv >> prov2

paste -d"," prov1 prov2 > ./simulations_ils_2.csv

rm prov1
rm prov2


####################


echo "dataset,option" > prov1
echo "nb_gene,ntopo0,ntopo1,ntopo2,ntopo3,mean_lg,tau1,tau1_l,tau1_h,tau2,tau2_l,tau2_h,theta,theta_l,theta_h,pab,pab_l,pab_h,pac,pac_l,pac_h,pbc,pbc_l,pbc_h,pa,pa_l,pa_h,noevent,noconflict_ILS,noconflict_GF,conflict_ILS,conflict_ILS_l,conflict_ILS_h,conflict_GF,conflict_GF_l,conflict_GF_h,imbalance_ILS,dominant_ILS,imbalance_GF,dominant_GF,lnL" > prov2

echo ./aphid_input/simulations.tax,basic.opt >> prov1
../../software/aphid/aphid aphid_input/simulations_ils_33.in aphid_input/simulations.tax aphid_input/config.opt outputs/simulations_ils_33.csv >> prov2

paste -d"," prov1 prov2 > ./simulations_ils_33.csv

rm prov1
rm prov2
