#!/bin/bash

python scripts/process_aphid.py --taxon simulation_ILS_2 --aphid_standard ./simulations_ils_2.csv --aphid_output ./outputs/simulations_ils_2.csv -o ./processed/simulations_ils_2_processed.csv --times 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0
python scripts/process_aphid.py --taxon simulation_ILS_33 --aphid_standard ./simulations_ils_33.csv --aphid_output ./outputs/simulations_ils_33.csv -o ./processed/simulations_ils_33_processed.csv --times 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0
