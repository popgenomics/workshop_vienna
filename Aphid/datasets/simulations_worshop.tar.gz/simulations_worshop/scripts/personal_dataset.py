import os
import random

def personal_dataset(AC, CA, BC, CB, AB, no_event, trees):
    selected = []

    if int(AC) > 0:
        select = random.choices(trees['AC'], k=int(AC))
        selected += select
    if int(CA) > 0:
        select = random.choices(trees['CA'], k=int(CA))
        selected += select
    if int(BC) > 0:
        select = random.choices(trees['BC'], k=int(BC))
        selected += select
    if int(CB) > 0:
        select = random.choices(trees['CB'], k=int(CB))
        selected += select
    if int(AB) > 0:
        select = random.choices(trees['AB'], k=int(AB))
        selected += select
    if int(no_event) > 0:
        select = random.choices(trees['no_event'], k=int(no_event))
        selected += select

    string = ''
    cnt = 0
    for i in selected:
        cnt += 1
        string += f'{i}\t{1000}\tgene_{cnt}\n'

    return string

trees = {'AC':[],
         'CA':[],
         'BC':[],
         'CB':[],
         'AB':[],
         'no_event':[]}

with open('./trees/ils_2/AC/AC.trees') as filein:
    for line in filein:
        trees['AC'].append(line.rstrip())

with open('./trees/ils_2/CA/CA.trees') as filein:
    for line in filein:
        trees['CA'].append(line.rstrip())

with open('./trees/ils_2/BC/BC.trees') as filein:
    for line in filein:
        trees['BC'].append(line.rstrip())

with open('./trees/ils_2/CB/CB.trees') as filein:
    for line in filein:
        trees['CB'].append(line.rstrip())

with open('./trees/ils_2/AB/AB.trees') as filein:
    for line in filein:
        trees['AB'].append(line.rstrip())

with open('./trees/ils_2/no_event/no_event.trees') as filein:
    for line in filein:
        trees['no_event'].append(line.rstrip())

print('Enter the number of trees with gene flow from 1 to 3 (between 0 and 10000)')
AC = int(input())
print('Enter the number of trees with gene flow from 3 to 1 (between 0 and 10000)')
CA = int(input())
print('Enter the number of trees with gene flow from 2 to 3 (between 0 and 10000)')
BC = int(input())
print('Enter the number of trees with gene flow from 3 to 2 (between 0 and 10000)')
CB = int(input())
print('Enter the number of trees with gene flow from 1 to 2 (between 0 and 10000)')
AB = int(input())
print('Enter the number of trees without gene flow (between 0 and 10000)')
no_event = int(input())


counter = AC + CA + BC + CB + AB + no_event
input = personal_dataset(AC=AC, CA=CA, BC=BC, CB=CB, AB=AB, no_event=no_event, trees=trees)

with open('./aphid_input/simulations_ils_2.in', 'w') as fileout:
    fileout.write(input)

p_AC = round(AC / counter, 3)
p_CA = round(CA / counter, 3)
p_BC = round(BC / counter, 3)
p_CB = round(CB / counter, 3)
p_AB = round(AB / counter, 3)
p_no_event = round(no_event / counter, 3)

string_2 = f"Your dataset simulations_ils_2.in contains:\n\t- {p_AC}, trees with GF from A to C\n\t- {p_CA}, trees with GF from C to A\n\t- {p_BC}, trees with GF from B to C\n\t- {p_CB}, trees with GF from C to B\n\t- {p_AB}, trees with GF from A to B\n\t- {p_no_event}, trees without GF\n\t- 2% of ILS"
print(string_2)

####

trees = {'AC':[],
         'CA':[],
         'BC':[],
         'CB':[],
         'AB':[],
         'no_event':[]}

with open('./trees/ils_33/AC/AC.trees') as filein:
    for line in filein:
        trees['AC'].append(line.rstrip())

with open('./trees/ils_33/CA/CA.trees') as filein:
    for line in filein:
        trees['CA'].append(line.rstrip())

with open('./trees/ils_33/BC/BC.trees') as filein:
    for line in filein:
        trees['BC'].append(line.rstrip())

with open('./trees/ils_33/CB/CB.trees') as filein:
    for line in filein:
        trees['CB'].append(line.rstrip())

with open('./trees/ils_33/AB/AB.trees') as filein:
    for line in filein:
        trees['AB'].append(line.rstrip())

with open('./trees/ils_33/no_event/no_event.trees') as filein:
    for line in filein:
        trees['no_event'].append(line.rstrip())

input = personal_dataset(AC=AC, CA=CA, BC=BC, CB=CB, AB=AB, no_event=no_event, trees=trees)

with open('./aphid_input/simulations_ils_33.in', 'w') as fileout:
    fileout.write(input)

p_AC = round(AC / counter, 3)
p_CA = round(CA / counter, 3)
p_BC = round(BC / counter, 3)
p_CB = round(CB / counter, 3)
p_AB = round(AB / counter, 3)
p_no_event = round(no_event / counter, 3)

string_33 = f"Your dataset simulations_ils_33.in contains:\n\t- {p_AC}, trees with GF from A to C\n\t- {p_CA}, trees with GF from C to A\n\t- {p_BC}, trees with GF from B to C\n\t- {p_CB}, trees with GF from C to B\n\t- {p_AB}, trees with GF from A to B\n\t- {p_no_event}, trees without GF\n\t- 33% of ILS"
print(string_33)

final_string = string_2 + '\n' + string_33

with open('./simulations proportions.txt', 'w') as fileout:
    fileout.write(final_string)